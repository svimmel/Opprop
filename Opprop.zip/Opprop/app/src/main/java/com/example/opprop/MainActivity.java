package com.example.opprop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText mtekstEpost;
    EditText mtekstPassord;
    Button mKnappLogin;
    TextView mTextViewRegister;
    DatabaseHjelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHjelper(this);
        mtekstEpost = (EditText)findViewById(R.id.edittext_epost);
        mtekstPassord = (EditText)findViewById(R.id.edittext_passord);
        mKnappLogin = (Button) findViewById(R.id.knapp_login);
        mTextViewRegister = (TextView) findViewById(R.id.textview_register);
        mTextViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Registrering = new Intent(MainActivity.this, RegisterAktivitet.class);
                startActivity(Registrering);

            }
        });

        mKnappLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String epost = mtekstEpost.getText().toString().trim();
                String pord = mtekstPassord.getText().toString().trim();
                Boolean res = db.sjekkBruker(epost,pord);
                if (res==true)
                {
                    Intent hovedMeny = new Intent(MainActivity.this, HovedAktivitet.class );
                    startActivity(hovedMeny);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT ).show();
                }
            }
        });
    }
}
