package com.example.opprop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterAktivitet extends AppCompatActivity {
    DatabaseHjelper db;
    EditText mtekstEpost;
    EditText mtekstPassord;
    EditText mtekstBekreftPassord;
    Button mKnappRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_aktivitet);

        db = new DatabaseHjelper(this);
        mtekstEpost = (EditText)findViewById(R.id.edittext_epost);
        mtekstPassord = (EditText)findViewById(R.id.edittext_passord);
        mtekstBekreftPassord= (EditText) findViewById(R.id.edittext_bekreft);
        mKnappRegister = (Button) findViewById(R.id.knapp_register);

        mKnappRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String epost = mtekstEpost.getText().toString().trim();
                String pord =  mtekstPassord.getText().toString().trim();
                String bekreft = mtekstBekreftPassord.getText().toString().trim();

                if (pord.equals(bekreft)){
                    long val = db.addBruker(epost,pord);
                    if (val > 0){
                        Toast.makeText(RegisterAktivitet.this, "Vellyket", Toast.LENGTH_SHORT ).show();
                        Intent sendTilLogin = new Intent(RegisterAktivitet.this, MainActivity.class);
                        startActivity(sendTilLogin);}
                    else{
                        Toast.makeText(RegisterAktivitet.this, "Registrering error", Toast.LENGTH_SHORT ).show();
                    }

                }
                else {
                    Toast.makeText(RegisterAktivitet.this, "Passordet matchet ikke", Toast.LENGTH_SHORT ).show();
                }
            }
        });
    }

}
