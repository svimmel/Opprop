package com.example.opprop;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHjelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAVN ="register.db";
    public static final String TABELL_NAVN ="registerbruker";
    public static final String COL_1 ="ID";
    public static final String COL_2 ="epost";
    public static final String COL_3 ="passord";

    public DatabaseHjelper(@Nullable Context context ) {
        super(context, DATABASE_NAVN, null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE registerbruker (ID INTEGER PRIMARY KEY AUTOINCREMENT, epost TEXT, passord TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABELL_NAVN);
        onCreate(sqLiteDatabase);

    }

    public long addBruker(String epost, String passord) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(" epost ",epost);
        contentValues.put(" passord ",passord);
        long res = db.insert("registerbruker", null, contentValues);
        db.close();
        return res;
    }

    public boolean sjekkBruker ( String epost, String passord){

        String[] kolonne = {COL_1};
        SQLiteDatabase db = getReadableDatabase();
        String valg = COL_2 + "=?" + " and " + COL_3 + "=?";
        String[] valgArgs = { epost, passord};
        Cursor markor = db.query(TABELL_NAVN, kolonne, valg, valgArgs, null, null, null);
        int count = markor.getCount();
        markor.close();
        db.close();

        if (count>0)
            return true;
        else
            return false;

    }

}
